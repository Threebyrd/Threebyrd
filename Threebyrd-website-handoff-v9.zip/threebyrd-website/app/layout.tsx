import type { Metadata } from "next";
import { Geist } from "next/font/google";
import { headers } from "next/headers";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

export async function generateMetadata(): Promise<Metadata> {
  const requestHeaders = await headers();
  const host = requestHeaders.get("x-forwarded-host") ?? requestHeaders.get("host") ?? "localhost:3000";
  const protocol = requestHeaders.get("x-forwarded-proto") ?? (host.startsWith("localhost") ? "http" : "https");
  const origin = `${protocol}://${host}`;

  return {
    title: "Threebyrd Meal Prep - Chicken and Beef Meal Prep",
    description:
      "Chicken and beef meal prep in two portion sizes, with rice and broccoli. Online ordering is coming soon.",
    openGraph: {
      title: "Threebyrd Meal Prep",
      description:
        "Chicken and beef meal prep in two portion sizes. Online ordering is coming soon.",
      type: "website",
      images: [
        {
          url: `${origin}/og.png`,
          width: 1200,
          height: 630,
          alt: "Threebyrd Meal Prep social preview",
        },
      ],
    },
    twitter: {
      card: "summary_large_image",
      title: "Threebyrd Meal Prep",
      description:
        "Chicken and beef meal prep in two portion sizes. Online ordering is coming soon.",
      images: [`${origin}/og.png`],
    },
    icons: {
      icon: "/favicon.svg",
      shortcut: "/favicon.svg",
    },
  };
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={`${geistSans.variable} antialiased`}>{children}</body>
    </html>
  );
}
